# Asgard-crack
A tool to use asgard for free.

It's free, don't sell it please.

Asgard download:
https://cdn.discordapp.com/attachments/804178032280600647/986163950079053874/A-R.exe


HOW TO USE:

1. open redirector.exe, u need to do it only once and after that u can use asgard any time
2. open A-R.exe (asgard loader) and login with random username and password, press login.
3. boom, done, u can play.
